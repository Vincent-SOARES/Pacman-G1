package fr.imt.albi.pacman.utils;

public class Wall extends Square {
	public Wall(int size, int x, int y, String color) {
		super(size, x, y, color);
	}
}
